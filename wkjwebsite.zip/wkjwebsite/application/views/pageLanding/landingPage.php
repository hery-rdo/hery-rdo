	<!--====== HEADER PART START ======-->

	<header class="header-area">
		<div class="navbar-area">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<nav class="navbar navbar-expand-lg">
							<a class="navbar-brand" href="index.html">
								<img src="<?= base_url() ?>assets/images/logo.svg" alt="Logo">
							</a>
							<button class="navbar-toggler" type="button" data-toggle="collapse"
								data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
								aria-expanded="false" aria-label="Toggle navigation">
								<span class="toggler-icon"></span>
								<span class="toggler-icon"></span>
								<span class="toggler-icon"></span>
							</button>

							<div class="collapse navbar-collapse sub-menu-bar" id="navbarSupportedContent">
								<ul id="nav" class="navbar-nav ml-auto">
									<li class="nav-item active">
										<a class="page-scroll" href="<?= site_url("landing") ?>">Beranda</a>
									</li>
									<li class="nav-item">
									<a class="page-scroll" href="<?= site_url("landing/buku") ?>">Buku</a>
								</li>
									<li class="nav-item">
										<a class="page-scroll" href="<?= site_url("landing/produk") ?>">Produk</a>
									</li>
									<li class="nav-item">
										<a class="page-scroll" href="#particles-2">Kontak</a>
									</li>
								</ul>
							</div> <!-- navbar collapse -->
						</nav> <!-- navbar -->
					</div>
				</div> <!-- row -->
			</div> <!-- container -->
		</div> <!-- navbar area -->

		<div id="home" class="header-hero bg_cover"
			style="background-image: url(<?= base_url() ?>assets/images/banner-bg2.svg)">
			<div class="container">
				<div class="row justify-content-center">
					<div class="col-lg-8">
						<div class="header-hero-content text-center">
							<h2 class="header-title wow fadeInUp" data-wow-duration="1.3s" data-wow-delay="0.2s">
								Penerbit, Percetakan, Toko Buku, ATK, Dll</h2>
						</div> <!-- header hero content -->
					</div>
				</div> <!-- row -->
				<div class="row">
					<div class="col-lg-12">
						<div class="header-hero-image text-center wow fadeIn" data-wow-duration="1.3s"
							data-wow-delay="1.4s">
							<img class="img-hover" src="<?= base_url() ?>assets/images/logo-5.svg"
								alt="hero">
						</div> <!-- header hero image -->
					</div>
				</div> <!-- row -->
			</div> <!-- container -->
			<div id="particles-1" class="particles"></div>
		</div> <!-- header hero -->
	</header>
	
	<!--====== BRAMD PART START ======-->

	<div class="brand-area pt-10">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="brand-logo d-flex align-items-center justify-content-center justify-content-md-between">
						<div class="single-logo mt-30 wow fadeIn" data-wow-duration="1s" data-wow-delay="0.2s">
							<a href="https://siplah.kemdikbud.go.id/"><img height="70px"
									src="https://i.ibb.co/7kBJd8d/siplah-logo.png" alt="brand"></a>
						</div> <!-- single logo -->
						<div class="single-logo mt-30 wow fadeIn" data-wow-duration="1.5s" data-wow-delay="0.2s">
							<a
								href="https://siplah.blibli.com/merchant-detail/SWKJ-0001?itemPerPage=40&page=0&merchantId=SWKJ-0001"><img
									height="70px" src="https://siplahtelkom.com/assets/siplah/siplah-logo.svg"
									alt="brand"></a>
						</div> <!-- single logo -->
						<div class="single-logo mt-30 wow fadeIn" data-wow-duration="1.5s" data-wow-delay="0.3s">
							<a href="https://siplahtelkom.com/store/3399-wahana-karya-jaya?parent_dtids=all"><img
									height="70px"
									src="https://siplah.kemdikbud.go.id/themes/user/site/default/asset/file_upload/Siplah_Blibli_Logo.png"
									alt="brand"></a>
						</div> <!-- single logo -->
					</div> <!-- brand logo -->
				</div>
			</div> <!-- row -->
		</div> <!-- container -->
	</div>

	<!--====== BRAMD PART ENDS ======-->

	<!--====== SERVICES PART START ======-->
	<!-- Background Carousel -->
	<div id="carouselExampleIndicators" class="carousel slide mt-100" data-ride="carousel">
		<ol class="carousel-indicators">
			<li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
			<li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
			<li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
		</ol>
		<div class="carousel-inner shadow-lg">
			<div class="carousel-item active">
				<img style="background-size: cover; height: 100vh; min-height: 350px;" class="d-block img-fluid w-100"
					src="https://a-static.besthdwallpaper.com/pantai-3d-wallpaper-1280x720-73_45.jpg" alt="First slide">
			</div>
			<div class="carousel-item">
				<img style="background-size: cover; height: 100vh; min-height: 350px;" class="d-block img-fluid w-100"
					src="https://www.xtrafondos.com/en/descargar.php?id=6908&resolucion=1280x720" alt="Second slide">
			</div>
			<div class="carousel-item">
				<img style="background-size: cover; height: 100vh; min-height: 350px;" class="d-block img-fluid w-100"
					src="https://cdn.wallpapersafari.com/3/46/i8qU1x.jpg" alt="Third slide">
			</div>
		</div>
		<a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
			<span class="carousel-control-prev-icon" aria-hidden="true"></span>
			<span class="sr-only">Previous</span>
		</a>
		<a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
			<span class="carousel-control-next-icon" aria-hidden="true"></span>
			<span class="sr-only">Next</span>
		</a>
	</div>
	<!-- end background -->
	<section id="features" class="services-area pt-100">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-lg-10">
					<div class="section-title text-center pb-40">
						<div class="line m-auto"></div>
						<h3 class="title">Kami melayani segala kebutuhan sekolah anda, <span> Comes with everything you
								need to get started!</span></h3>
					</div> <!-- section title -->
				</div>
			</div> <!-- row -->

			<div class="row justify-content-center">
				<div class="col-lg-4 col-md-7 col-sm-8">
					<div class="single-services text-center mt-30 wow fadeIn" data-wow-duration="1s"
						data-wow-delay="0.2s">
						<div class="services-icon">
							<img class="img-fluid"
								src="https://www.duniadosen.com/wp-content/uploads/2020/02/careerwebindia123com.jpg"
								alt="">
						</div>
						<div class="services-content mt-30">
							<h4 class="services-title"><a href="#">Penerbit</a></h4>
						</div>
					</div> <!-- single services -->
				</div>
				<div class="col-lg-4 col-md-7 col-sm-8">
					<div class="single-services text-center mt-30 wow fadeIn" data-wow-duration="1s"
						data-wow-delay="0.5s">
						<div class="services-icon">
							<img class="" src="<?= base_url() ?>assets/images/banner-bg3.png" alt="">
						</div>
						<div class="services-content mt-30">
							<h4 class="services-title"><a href="#">Offset & Digital Printing</a></h4>
						</div>
					</div> <!-- single services -->
				</div>
				<div class="col-lg-4 col-md-7 col-sm-8">
					<div class="single-services text-center mt-30 wow fadeIn" data-wow-duration="1s"
						data-wow-delay="0.8s">
						<div class="services-icon">
							<img class="" src="<?= base_url() ?>assets/images/banner-bg5.png" alt="">
						</div>
						<div class="services-content mt-30">
							<h4 class="services-title"><a href="#">Toko Buku & ATK</a></h4>
						</div> <!-- single services -->
					</div>
				</div> <!-- row -->
			</div>
		</div><!-- container -->
	</section>

	<section style="bottom: -5;" class="pt-100 subscribe-content">
		<div class="container">
			<div class="wow fadeIn" data-wow-duration="1s" data-wow-delay="0.5s">
				<div class="row justify-content-center">
					<div class="card">
						<div style="background-position: center; background-size: cover; background-image: url('https://static.vecteezy.com/ti/vetor-gratis/p1/4805307-flat-design-abstract-background-soft-liquid-shapes-template-with-modern-gradiente-background-colors-cool-esthetic-background-design-apropriado-para-social-media-post-mobile-app-banner-anuncios-da-web-gr%C3%A1tis-vetor.jpg');"
							class="card-body rounded shadow-lg">
							<div class="col-lg-12">
								<div class="section-title text-center pb-40">
									<div class="line m-auto"></div>
									<h3 class="title">Hubungi kami untuk segala kebutuhan sekolah anda <br> <span> Comes
											with everything you
											need to get started!</span></h3>
								</div> <!-- section title -->
							</div>
							<div class="col-lg-12 col-md-6">
								<div id="multi-item-example" class="carousel slide carousel-multi-item"
									data-ride="carousel">
									<!--Controls-->
									<a class="carousel-control-prev" href="#multi-item-example" role="button"
										data-slide="prev">
										<span class="carousel-control-prev-icon" aria-hidden="true"></span>
										<span class="sr-only">Previous</span>
									</a>
									<a class="carousel-control-next" href="#multi-item-example" role="button"
										data-slide="next">
										<span class="carousel-control-next-icon" aria-hidden="true"></span>
										<span class="sr-only">Next</span>
									</a>
									<!-- <a class="carousel-control-prev" href="#multi-item-example" role="button"
										data-slide="prev">
										<span class="carousel-control-prev-icon" aria-hidden="true"></span>
										<span class="sr-only text-dark">Previous</span>
									</a>
									<a class="carousel-control-next" href="#multi-item-example" role="button"
										data-slide="next">
										<span class="carousel-control-next-icon" aria-hidden="true"></span>
										<span class="sr-only text-dark">Next</span>
									</a> -->
									<!--/.Controls-->

									<!--Indicators-->
									<ol style="bottom: -20px;" class="carousel-indicators">
										<li data-target="#multi-item-example" data-slide-to="0" class="active bg-dark">
										</li>
										<li data-target="#multi-item-example" data-slide-to="1" class="bg-dark"></li>
									</ol>
									<!--/.Indicators-->

									<!--Slides-->
									<div class="carousel-inner" role="listbox">

										<!--First slide-->
										<div class="carousel-item active">

											<div class="col-md-3" style="float:left">
												<div class="card mb-2">
													<img class="card-img-top" width="100px" height="150px"
														src="http://4.bp.blogspot.com/-sORCTFbLKI4/VZc7bw-hdcI/AAAAAAAAF4I/-9q9lF7ozis/s1600/buku-sekolah.jpg"
														alt="Card image cap">
													<div class="card-body">
														<h4 class="card-title">Buku Paket & LKS</h4>
														<p class="card-text text-justify">Some quick example text to
															build on the card title
															and make up
															the bulk of the
															card's content.</p>
													</div>
												</div>
											</div>

											<div class="col-md-3" style="float:left">
												<div class="card mb-2">
													<img class="card-img-top" width="100px" height="150px"
														src="https://i0.wp.com/harga.web.id/wp-content/uploads/Harga-Mesin-Digital-Printing-A3-Plus-di-Pasaran-qpock.jpg?resize=680%2C300&ssl=1"
														alt="Card image cap">
													<div class="card-body">
														<h4 class="card-title">Laser Print</h4>
														<p class="card-text text-justify">Some quick example text to
															build on the card title
															and make up
															the bulk of the
															card's content.</p>
													</div>
												</div>
											</div>

											<div class="col-md-3" style="float:left">
												<div class="card mb-2">
													<img class="card-img-top" width="100px" height="150px"
														src="https://image.cermati.com/q_70/rjcuajbxdl6vmh7pofpj"
														alt="Card image cap">
													<div class="card-body">
														<h4 class="card-title">Cetak Banner</h4>
														<p class="card-text text-justify">Some quick example text to
															build on the card title
															and make up
															the bulk of the
															card's content.</p>
													</div>
												</div>
											</div>

											<div class="col-md-3" style="float:left">
												<div class="card mb-2">
													<img class="card-img-top" width="100px" height="150px"
														src="https://panata-tunggal.com/wp-content/uploads/2021/06/WhatsApp-Image-2021-05-27-at-08.55.45-1-1024x595.jpeg"
														alt="Card image cap">
													<div class="card-body">
														<h4 class="card-title">Souvenir</h4>
														<p class="card-text text-justify">Some quick example text to
															build on the card title
															and make up
															the bulk of the
															card's content.</p>
													</div>
												</div>
											</div>

										</div>
										<!--/.First slide-->

										<!--Second slide-->
										<div class="carousel-item">

											<div class="col-md-3 shadow-sm" style="float:left">
												<div class="card mb-2">
													<img class="card-img-top" width="100px" height="150px"
														src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTgEqr4Y2EFuNCUpwbyXj3nmRlXS7doeZ32ig&usqp=CAU"
														alt="Card image cap">
													<div class="card-body">
														<h4 class="card-title">Perangkat Elektronik</h4>
														<p class="card-text text-justify">Some quick example text to
															build on the card title
															and make up
															the bulk of the
															card's content.</p>
													</div>
												</div>
											</div>

											<div class="col-md-3 shadow-sm" style="float:left">
												<div class="card mb-2">
													<img class="card-img-top" width="100px" height="150px"
														src="https://ipc.disnakerperin.surakarta.go.id/gambar/produk/1535951883849662_3.jpg"
														alt="Card image cap">
													<div class="card-body">
														<h4 class="card-title">Furniture</h4>
														<p class="card-text text-justify">Some quick example text to
															build on the card title
															and make up
															the bulk of the
															card's content.</p>
													</div>
												</div>
											</div>

											<div class="col-md-3 shadow-sm" style="float:left">
												<div class="card mb-2">
													<img class="card-img-top" width="100px" height="150px"
														src="https://sentracetak.com/wp-content/uploads/2020/09/cetak-buku-banyak.jpg"
														alt="Card image cap">
													<div class="card-body">
														<h4 class="card-title">Offset</h4>
														<p class="card-text text-justify">Some quick example text to
															build on the card title
															and make up
															the bulk of the
															card's content.</p>
													</div>
												</div>
											</div>

											<div class="col-md-3 shadow-sm" style="float:left">
												<div class="card mb-2">
													<img class="card-img-top" width="100px" height="150px"
														src="https://mdbootstrap.com/img/Photos/Horizontal/City/4-col/img%20(47).jpg"
														alt="Card image cap">
													<div class="card-body">
														<h4 class="card-title">Card title</h4>
														<p class="card-text text-justify">Some quick example text to
															build on the card title
															and make up
															the bulk of the
															card's content.</p>
													</div>
												</div>
											</div>

										</div>
										<!--/.Second slide-->



									</div>
									<!--/.Slides-->

								</div>
							</div>
						</div>
					</div>
				</div> <!-- row -->
			</div>
		</div>
	</section>
	<!--====== SERVICES PART ENDS ======-->