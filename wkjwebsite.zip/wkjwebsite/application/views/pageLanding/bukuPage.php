<header class="header-area">
	<div class="navbar-area">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<nav class="navbar navbar-expand-lg">
						<a class="navbar-brand" href="index.html">
							<img src="<?= base_url() ?>assets/images/logo.svg" alt="Logo">
						</a>
						<button class="navbar-toggler" type="button" data-toggle="collapse"
							data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
							aria-expanded="false" aria-label="Toggle navigation">
							<span class="toggler-icon"></span>
							<span class="toggler-icon"></span>
							<span class="toggler-icon"></span>
						</button>

						<div class="collapse navbar-collapse sub-menu-bar" id="navbarSupportedContent">
							<ul id="nav" class="navbar-nav ml-auto">
								<li class="nav-item active">
									<a class="page-scroll" href="<?= site_url("landing") ?>">Beranda</a>
								</li>
                                <li class="nav-item">
									<a class="page-scroll" href="<?= site_url("landing/buku") ?>">Buku</a>
								</li>
								<li class="nav-item">
									<a class="page-scroll" href="<?= site_url("landing/produk") ?>">Produk</a>
								</li>
								<li class="nav-item">
									<a class="page-scroll" href="#particles-2">Kontak</a>
								</li>
							</ul>
						</div> <!-- navbar collapse -->
					</nav> <!-- navbar -->
				</div>
			</div> <!-- row -->
		</div> <!-- container -->
	</div> <!-- navbar area -->
</header>
<div id="navbar" class="pt-100"></div>
<div class="container bg-light">
	
</div>
<div class="container pb-100">
	<div class="row">
		<div class="col-md-3 pt-10">
			<div class="card shadow-lg">
				<div class="hovered">
					<img class="img-thumbnail" src="https://snapy.co.id/gambar/galeri/Buku-Tulis-1.jpg" class="card-img-top" alt="...">
					<div class="overlay">
						<div class="font">
							<a href="1">
								<span class="text-light">SipLah Blibli</span>
							</a>
							<a href="2">
								<span class="text-light">SipLah Telkom</span>
							</a>
						</div>
					</div>
				</div>
				<div class="card-header">
					<h5 class="card-title">Belajar Bootstrap 4</h5>
				</div>
				<div class="card-body">
					<label for="ISBN" class="card-text">ISBN :</label>
					<span><a href="#">928-623-6588-32-5</a></span><br>
					<label for="penulis">Penulis :</label>
					<span>Rahardian</span>
				</div>
				<div class="card-footer">
					<a class="pull-right" href="#">Detail >></a>
				</div>
			</div>
		</div>
		<div class="col-md-3 pt-10">
			<div class="card shadow-lg">
				<div class="hovered">
					<img class="img-thumbnail" src="https://snapy.co.id/gambar/galeri/Buku-Tulis-1.jpg" class="card-img-top" alt="...">
					<div class="overlay">
						<div class="font">
							<a href="1">
								<span class="text-light">SipLah Blibli</span>
							</a>
							<a href="2">
								<span class="text-light">SipLah Telkom</span>
							</a>
						</div>
					</div>
				</div>
				<div class="card-header">
					<h5 class="card-title">Belajar Bootstrap 4</h5>
				</div>
				<div class="card-body">
					<label for="ISBN" class="card-text">ISBN :</label>
					<span><a href="#">928-623-6588-32-5</a></span><br>
					<label for="penulis">Penulis :</label>
					<span>Rahardian</span>
				</div>
				<div class="card-footer">
					<a class="pull-right" href="#">Detail >></a>
				</div>
			</div>
		</div>
		<div class="col-md-3 pt-10">
			<div class="card shadow-lg">
				<div class="hovered">
					<img class="img-thumbnail" src="https://snapy.co.id/gambar/galeri/Buku-Tulis-1.jpg" class="card-img-top" alt="...">
					<div class="overlay">
						<div class="font">
							<a href="1">
								<span class="text-light">SipLah Blibli</span>
							</a>
							<a href="2">
								<span class="text-light">SipLah Telkom</span>
							</a>
						</div>
					</div>
				</div>
				<div class="card-header">
					<h5 class="card-title">Belajar Bootstrap 4</h5>
				</div>
				<div class="card-body">
					<label for="ISBN" class="card-text">ISBN :</label>
					<span><a href="#">928-623-6588-32-5</a></span><br>
					<label for="penulis">Penulis :</label>
					<span>Rahardian</span>
				</div>
				<div class="card-footer">
					<a href="#" class="pull-right">Detail >></a>
				</div>
			</div>
		</div>
		<div class="col-md-3 pt-10">
			<div class="card shadow-lg">
				<div class="hovered">
					<img class="img-thumbnail" src="https://snapy.co.id/gambar/galeri/Buku-Tulis-1.jpg" class="card-img-top" alt="...">
					<div class="overlay">
						<div class="font">
							<a href="1">
								<span class="text-light">SipLah Blibli</span>
							</a>
							<a href="2">
								<span class="text-light">SipLah Telkom</span>
							</a>
						</div>
					</div>
				</div>
				<div class="card-header">
					<h5 class="card-title">Belajar Bootstrap 4</h5>
				</div>
				<div class="card-body">
					<label for="ISBN" class="card-text">ISBN :</label>
					<span><a href="#">928-623-6588-32-5</a></span><br>
					<label for="penulis">Penulis :</label>
					<span>Rahardian</span>
				</div>
				<div class="card-footer">
					<a href="#" class="pull-right">Detail >></a>
				</div>
			</div>
		</div>
	</div>
</div>
