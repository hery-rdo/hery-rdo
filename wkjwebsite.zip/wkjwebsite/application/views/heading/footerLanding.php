<!--====== FOOTER PART START ======-->

<footer id="footer" class="footer-area">
		<div class="container">
			 <!-- subscribe area -->
			<div class="footer-widget pb-80">
				<div class="row">
					<div class="col-lg-4 col-md-6 col-sm-8">
						<div class="mt-100 wow fadeIn" data-wow-duration="1s" data-wow-delay="0.2s">
							<a class="logo" href="#">
								<img height="50px" src="<?= base_url() ?>assets/images/logo-3.svg" alt="logo">
							</a>
							<div class="footer-about">
								<p class="text text-justify"><b>Melayani segala kebutuhan sekolah anda,</b><br> kami juga menyediakan
									perangkat elektronik yang anda butuhkan mulai dari laptop, CPU, projektor, printer,
									kipas angin, AC, sound, audio mixer, dll, kami juga menyediakan kebutuhan meubel
									anda mulai dari lemari besi dan kayu, meja, bangku, dll</p>
								<ul class="social">
									<li><a href="#"><i class="lni-facebook-filled"></i></a></li>
									<li><a href="#"><i class="lni-twitter-filled"></i></a></li>
									<li><a href="#"><i class="lni-instagram-filled"></i></a></li>
									<li><a href="#"><i class="lni-linkedin-original"></i></a></li>
								</ul>
							</div>
						</div> <!-- footer about -->
					</div>
					<div class="col-lg-5 col-md-7 col-sm-7">
						<div class="footer-link d-flex mt-100 justify-content-md-between">

							<div class="link-wrapper wow fadeIn" data-wow-duration="1s" data-wow-delay="0.6s">
								<div class="footer-title">
									<h4 class="title">Marketplace</h4>
								</div>
								<ul class="link">
									<li><a href="https://bit.ly/wkjtoko">SipLah Blibli</a></li>
									<li><a href="https://bit.ly/tokowkj1">SipLah Telkom</a></li>
								</ul>
							</div> <!-- footer wrapper -->
						</div> <!-- footer link -->
					</div>
					<div class="col-lg-3 col-md-5 col-sm-5">
						<div class="footer-contact mt-100 wow fadeIn" data-wow-duration="1s" data-wow-delay="0.8s">
							<div class="footer-title">
								<h4 class="title">Hubungi Kami</h4>
							</div>
							<ul class="contact">
								<li><i class="fa fa-phone"></i> : (0321) 4893 475</li>
								<li><i class="fa fa-whatsapp"></i> : 0858-5288-7333</li>
								<li><i class="fa fa-envelope"></i> : tokowkj@gmail.com</li>
								<li><i class="fa fa-globe"></i> : www.wkjbook.com</li>
								<li>Jl. Ring Road Mojoagung, Plemahan, Kec. Sumobito, Kab. Jombang<br>JAWA TIMUR (61482)
								</li>
							</ul>
						</div> <!-- footer contact -->
					</div>
				</div> <!-- row -->
			</div> <!-- footer widget -->
			<div class="footer-copyright">
				<div class="row">
					<div class="col-lg-12">
						<div class="copyright d-sm-flex justify-content-between">
							<div class="copyright-content">
								<p class="text">Designed and Developed by <a href="https://uideck.com"
										rel="nofollow">UIdeck</a></p>
							</div> <!-- copyright content -->
						</div> <!-- copyright -->
					</div>
				</div> <!-- row -->
			</div> <!-- footer copyright -->
		</div> <!-- container -->
		<div id="particles-2"></div>
		<a href="#" class="back-to-top"><i class="fa fa-arrow-circle-o-up"></i></a>
	</footer>

	<!--====== Jquery js ======-->
	<script src="<?= base_url() ?>assets/js/vendor/jquery-1.12.4.min.js"></script>
	<script src="">
		$('#carouselExampleIndicators').carousel({
			interval: 2000
		})
		$('#multi-item-example').carousel({
			interval: 2000
		})
	</script>

	<script src="<?= base_url() ?>assets/js/vendor/modernizr-3.7.1.min.js"></script>

	<!--====== Bootstrap js ======-->
	<script src="<?= base_url() ?>assets/js/popper.min.js"></script>
	<script src="<?= base_url() ?>assets/js/bootstrap.min.js"></script>

	<!--====== Plugins js ======-->
	<script src="<?= base_url() ?>assets/js/plugins.js"></script>

	<!--====== Slick js ======-->
	<script src="<?= base_url() ?>assets/js/slick.min.js"></script>

	<!--====== Ajax Contact js ======-->
	<script src="<?= base_url() ?>assets/js/ajax-contact.js"></script>

	<!--====== Counter Up js ======-->
	<script src="<?= base_url() ?>assets/js/waypoints.min.js"></script>
	<script src="<?= base_url() ?>assets/js/jquery.counterup.min.js"></script>

	<!--====== Magnific Popup js ======-->
	<script src="<?= base_url() ?>assets/js/jquery.magnific-popup.min.js"></script>

	<!--====== Scrolling Nav js ======-->
	<script src="<?= base_url() ?>assets/js/jquery.easing.min.js"></script>
	<script src="<?= base_url() ?>assets/js/scrolling-nav.js"></script>

	<!--====== wow js ======-->
	<script src="<?= base_url() ?>assets/js/wow.min.js"></script>

	<!--====== Particles js ======-->
	<script src="<?= base_url() ?>assets/js/particles.min.js"></script>

	<!--====== Main js ======-->
	<script src="<?= base_url() ?>assets/js/main.js"></script>

</body>

</html>
